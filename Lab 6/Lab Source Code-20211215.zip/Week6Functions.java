public class Week6Functions {
	int average(int[] inputArray) {
		// return the integer average of the values in inputArray
		// empty array should return an average of zero
		return 0;
	}

	float range(float[] inputArray) {
		// return the difference between the largest and smallest values in
		// inputArray. Empty array returns zero. All input values lie between
		// -1000.0f and 1000.0f
		return 0.0f;
	}

	int collatz(int i) {
		// if i is even, return i/2, otherwise return 3*i + 1
		return 0;
	}

	int compoundInterest(int capital, int ratePC, int years) {
		// return the new capital if compound interest at ratePC % per year is
		// accumulated by an integer amount (capital) over an integer number of years (years).
		// return value is rounded to *nearest* integer
		return 0;
	}
}
